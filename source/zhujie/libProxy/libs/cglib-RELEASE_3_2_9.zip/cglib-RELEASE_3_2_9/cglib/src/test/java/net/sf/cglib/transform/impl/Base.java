package net.sf.cglib.transform.impl;

public class Base {

    private String baseTest;
    
    /**
     * @return Returns the baseTest.
     */
    public String getBaseTest() {
        return baseTest;
    }
    /**
     * @param baseTest The baseTest to set.
     */
    public void setBaseTest(String baseTest) {
        this.baseTest = baseTest;
    }
}

