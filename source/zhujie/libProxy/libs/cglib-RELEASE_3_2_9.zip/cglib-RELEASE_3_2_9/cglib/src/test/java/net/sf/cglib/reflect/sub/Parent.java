package net.sf.cglib.reflect.sub;
abstract public class Parent extends GrandParent { }
